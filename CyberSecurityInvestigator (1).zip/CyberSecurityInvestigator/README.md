# CyberSecurityInvestigator

**CyberSecurityInvestigator** is a Termux-compatible cybersecurity research tool built with PhoneSploit and a demo brute-force wallet scanner (for legal research purposes only).

## 🔐 License Key Protected
To use the tool, a license key is required. Contact the developer:

- 📧 Email: saminu644@gmail.com
- 🌐 GitHub: https://github.com/Sanusi644

## ⚠️ Disclaimer
> This tool is for EDUCATIONAL PURPOSES ONLY.
> Do NOT use against unauthorized systems or wallets.
> You are fully responsible for your use.

## 🧰 Features
- PhoneSploit integration for ADB-based devices
- Brute-force wallet scan simulator (demo)
- Future module placeholders for Bash, SQL, HTML, Rust, Go

## 📥 Installation

```bash
apt update && apt install git python -y
git clone https://github.com/YourUsername/CyberSecurityInvestigator
cd CyberSecurityInvestigator
python3 CyberSecurityInvestigator.py
```

## 🔑 License Key Format
SYDSANUSI-2025-KEY123
(Contact author for access)

## 👨‍💻 Author
- **Cyrus Valen / Sanusi Saminu**
- GitHub: https://github.com/Sanusi644
- Tool maintained for research, cybersecurity education, and ethical hacking training.
